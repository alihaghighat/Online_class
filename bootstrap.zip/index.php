<?php
echo <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    <script src="js/jquery-1.11.2.min.js" type="text/javascript"></script>
    <script src="js/app.js" type="text/javascript"></script>
	<meta http-equiv="conent-type" content="text/html; charset=utf-8" />
	<title>سرویس شما ایجاد شد</title>
</head>
<body>
<center>
    <div class="message">
        <img src="images/service.jpg" />
    </div>
</center>

</body>
</html>
HTML;
?>