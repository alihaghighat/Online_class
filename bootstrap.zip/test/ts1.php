<?php
$api_key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmFwcGVhci5pbiIsImF1ZCI6Imh0dHBzOi8vYXBpLmFwcGVhci5pbi92MSIsImV4cCI6OTAwNzE5OTI1NDc0MDk5MSwiaWF0IjoxNjI2ODUxNjYxLCJvcmdhbml6YXRpb25JZCI6MTIxNTg4LCJqdGkiOiI5NWZkZmI4MS0xMzg0LTQzOGUtYjJiOS04YTQxMmRlMTQyMGUifQ.GA_dVm3FR36D6xEY0Cs47_VYvN5P8AqnLr6KaOzWxLk";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.whereby.dev/v1/meetings');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{
  "startDate": "2021-07-21T08:23:00.000Z",
  "endDate": "2021-07-22T08:22:00.000Z",
  "fields": ["bamplus.whereby.com"]}'
);

$headers = [
    'Authorization: Bearer ' . $api_key,
    'Content-Type: application/json'
];

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$response = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

curl_close($ch);

echo "Status code: $httpcode\n";
$data = json_decode($response);
echo "Room URL: ", $data->{'roomUrl'}, "\n";
echo "Host room URL: ", $data->{'hostRoomUrl'}, "\n";
?>